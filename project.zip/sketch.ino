/*
 * Fus Ro Dah | IoT Spark 4.0 | Property 2: Water-Leak Detection
 * Integrated Hardware Firmware + 3-Layer Secure MQTT-TLS + HMAC-SHA256
 *
 * SIMULATION 1 -> Wokwi: connects to "Wokwi-GUEST", slide pot = water sensor,
 *                 two push buttons = allowed badge (32) / unknown badge (21).
 * SIMULATION 0 -> Real board: connects to WIFI_SSID, water level sensor + RC522 RFID.
 */

#define SIMULATION 1

#include <Arduino.h>
#include <driver/gpio.h>
#include <DHT.h>
#include <ESP32Servo.h>
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <PubSubClient.h>
#include "mbedtls/md.h"

#if !SIMULATION
  #include <SPI.h>
  #include <MFRC522.h>
#endif

// ------------------------------------------------------------------ Wi-Fi & MQTT-TLS (Layer 2 & 3)
#if SIMULATION
  const char* WIFI_SSID = "Wokwi-GUEST";
  const char* WIFI_PASS = "";
#else
  const char* WIFI_SSID = "YOUR_REAL_WIFI_SSID";
  const char* WIFI_PASS = "YOUR_REAL_WIFI_PASSWORD";
#endif

const char* MQTT_BROKER    = "broker.emqx.io";
const int   MQTT_PORT_TLS  = 8883; // Layer 2: Encrypted TLS Port
const char* MQTT_USER      = "fusrodah_esp32";
const char* MQTT_PASS      = "iot_spark_secure_2026";

const char* TOPIC_STATUS   = "fusrodah/iotspark4/status";
const char* TOPIC_EVENTS   = "fusrodah/iotspark4/events";
const char* TOPIC_CSV      = "fusrodah/iotspark4/csv";
const char* TOPIC_COMMANDS = "fusrodah/iotspark4/commands";

// Layer 3: Shared secret key for HMAC-SHA256 command verification
const char* SHARED_SECRET  = "FUS_RO_DAH_SECRET_KEY_2026";
long lastSeq = 0;

WiFiClientSecure espClient;
PubSubClient mqtt(espClient);
unsigned long tMqttRetry = 0;

// ------------------------------------------------------------------ pins
const int PIN_WATER_SIG  = 33;  // water sensor signal (analog, ADC1). Has an internal pull-up.
const int PIN_WATER_PWR  = 25;  // powers the water sensor only while reading (less corrosion)
const int PIN_DHT        = 4;   // DHT22 data
const int PIN_SERVO      = 13;  // servo signal (the valve)
const int PIN_LED_RED    = 27;  // alarm: blinks on a leak or a sensor fault
const int PIN_LED_YELLOW = 26;  // water OFF
const int PIN_LED_GREEN  = 14;  // water ON
#if SIMULATION
const int PIN_BADGE_OK   = 32;  // button that acts like an allowed badge
const int PIN_BADGE_BAD  = 21;  // button that acts like an unknown badge
#else
const int PIN_RFID_SS    = 5;   // RC522 SDA. SCK 18, MISO 19, MOSI 23 (default SPI pins)
const int PIN_RFID_RST   = 22;
#endif

// ------------------------------------------------------------------ settings
const int   SAMPLE_MS     = 200;   // 5 readings per second
const int   WIN           = 25;    // window = 25 readings = 5 seconds
const int   HALF          = 13;    // readings in each half of the window
const int   DRY_LEVEL     = 150;   // below this the floor counts as dry
const int   WET_LEVEL     = 300;   // above this the floor counts as wet
const int   FLOOD_LEVEL   = 1800;  // this much water is a leak even if it stopped growing
const float GROW_RATE     = 20.0;  // units per second; BOTH halves must grow faster than this
const int   FAULT_LEVEL   = 4000;  // internal pull-up makes an unplugged sensor read about 4095
const int   CONFIRM_COUNT = 2;     // LEAK answers in a row before the water is closed
const unsigned long DRY_HOLD_MS = 3000; // floor must stay dry this long before reopening
const float HUMID_LEVEL   = 80.0;  // % humidity
const float HUMID_RATE    = 1.0;   // % per second
const int   SERVO_OPEN    = 0;     // servo angle when water flows
const int   SERVO_CLOSED  = 90;    // servo angle when the tube is pinched

#if !SIMULATION
const char* ALLOWED_UIDS[] = { "11:22:33:44" };
const int   ALLOWED_COUNT  = sizeof(ALLOWED_UIDS) / sizeof(ALLOWED_UIDS[0]);
#endif

// ------------------------------------------------------------------ objects and state
DHT   dht(PIN_DHT, DHT22);
Servo valve;
#if !SIMULATION
MFRC522 rfid(PIN_RFID_SS, PIN_RFID_RST);
#endif

enum State { WATER_ON, LEAK_OFF, FAULT_OFF, MANUAL_OFF };
enum Cls   { C_NORMAL, C_HUMID, C_SPILL, C_LEAK };
const char* STATE_NAME[] = { "WATER_ON", "LEAK_OFF", "FAULT_OFF", "MANUAL_OFF" };
const char* CLS_NAME[]   = { "NORMAL", "HUMID_AIR", "SMALL_SPILL", "LEAK" };

struct Features {
  float level;   // mean of the last second
  float slopeA;  // growth speed, first half of the window (units/s)
  float slopeB;  // growth speed, second half of the window (units/s)
  float minV, maxV;
  float hum;     // % (NAN if the DHT22 is broken)
  float humRate; // % per second
};

int      buf[WIN];
int      head = 0, count = 0;
Features feat = {0, 0, 0, 0, 0, NAN, 0};
State    state = WATER_ON;
Cls      lastCls = C_NORMAL;
int      leakCount = 0;
unsigned long firstLeakMs = 0;
bool     valveOpen = true;
bool     systemArmed = true; // True = monitoring active (OPEN), False = monitoring disarmed (CLOSED)
bool     alarmSilenced = false;
bool     waterFault = false, humFault = false;
int      faultHits = 0, okHits = 0;
bool     isDry = true;
unsigned long dryStart = 0;
float    hum = NAN, temp = NAN, prevHum = NAN, humRate = 0;
unsigned long prevHumMs = 0;
bool     csvOn = false;
int      label = -1;
unsigned long tSample = 0, tDecide = 0, tDht = 0, tBadge = 0;

// ------------------------------------------------------------------ small helpers
void event(const char* name, const char* extra) {
  char payload[256];
  snprintf(payload, sizeof(payload), "{\"ms\":%lu,\"event\":\"%s\"%s}", millis(), name, extra);
  Serial.printf("EVENT %s\n", payload);
  if (mqtt.connected()) {
    mqtt.publish(TOPIC_EVENTS, payload);
  }
}

bool alarmActive() { return state == LEAK_OFF || state == FAULT_OFF; }

int  flashesLeft = 0, flashLen = 100;
bool flashOn = false;
unsigned long flashT = 0;

void flash(int n, int len) { flashesLeft = n; flashLen = len; flashOn = false; flashT = 0; }

void updateLeds() {
  unsigned long now = millis();
  digitalWrite(PIN_LED_GREEN,  valveOpen ? HIGH : LOW);  // water ON
  digitalWrite(PIN_LED_YELLOW, valveOpen ? LOW : HIGH);  // water OFF

  bool red;
  if (flashesLeft > 0) {
    if (now - flashT >= (unsigned long)flashLen) {
      flashT = now;
      if (flashOn) flashesLeft--;
      flashOn = !flashOn;
    }
    red = flashOn;
  } else if (alarmActive()) {
    red = alarmSilenced ? true : (now / 250) % 2 == 0;  // blinking = new alarm, solid = seen
  } else {
    red = false;
  }
  digitalWrite(PIN_LED_RED, red ? HIGH : LOW);
}

// ------------------------------------------------------------------ valve
void closeWater(State s, const char* why) {
  valve.write(SERVO_CLOSED);
  valveOpen = false;
  state = s;
  alarmSilenced = false;
  char x[160];
  if (s == LEAK_OFF)
    snprintf(x, sizeof x, ",\"state\":\"%s\",\"reason\":\"%s\",\"detect_to_close_ms\":%lu",
             STATE_NAME[s], why, millis() - firstLeakMs);
  else
    snprintf(x, sizeof x, ",\"state\":\"%s\",\"reason\":\"%s\"", STATE_NAME[s], why);
  event("WATER_CLOSED", x);
}

bool tryOpen(const char* who) {
  char x[120];
  if (state == WATER_ON) {
    snprintf(x, sizeof x, ",\"by\":\"%s\",\"reason\":\"already open\"", who);
    event("OPEN_IGNORED", x);
    return false;
  }
  if (waterFault) {
    snprintf(x, sizeof x, ",\"by\":\"%s\",\"reason\":\"water sensor fault\"", who);
    event("OPEN_REFUSED", x);
    flash(3, 80);
    return false;
  }
  if (!isDry || millis() - dryStart < DRY_HOLD_MS) {
    snprintf(x, sizeof x, ",\"by\":\"%s\",\"reason\":\"floor still wet\"", who);
    event("OPEN_REFUSED", x);
    alarmSilenced = true;  // an allowed person is here: stop the blinking, keep the water off
    flash(3, 80);
    return false;
  }
  valve.write(SERVO_OPEN);
  valveOpen = true;
  state = WATER_ON;
  leakCount = 0;
  alarmSilenced = false;
  snprintf(x, sizeof x, ",\"by\":\"%s\"", who);
  event("WATER_OPENED", x);
  flash(1, 150);
  return true;
}

// ------------------------------------------------------------------ water sensor
int readWaterRaw() {
  digitalWrite(PIN_WATER_PWR, HIGH);
  gpio_pullup_en((gpio_num_t)PIN_WATER_SIG);  // no resistors: use the chip's own pull-up
  delay(5);                                   // let the sensor settle
  long sum = 0;
  for (int i = 0; i < 4; i++) sum += analogRead(PIN_WATER_SIG);
  digitalWrite(PIN_WATER_PWR, LOW);
  return sum / 4;
}

int sampleAt(int i) {  // i = 0 is the oldest reading in the window
  return buf[(head - count + i + 2 * WIN) % WIN];
}

void sampleWater() {
  int raw = readWaterRaw();

  // Unplugged sensor: the internal pull-up pulls the pin to about 4095.
  if (raw >= FAULT_LEVEL) {
    okHits = 0;
    if (++faultHits >= 3 && !waterFault) {
      waterFault = true;
      event("SENSOR_FAULT", ",\"sensor\":\"water\"");
      if (systemArmed && state != FAULT_OFF) closeWater(FAULT_OFF, "water sensor fault"); // safe state
    }
    return; // keep bad readings out of the window
  }
  faultHits = 0;
  if (waterFault && ++okHits >= 5) {
    waterFault = false;
    event("SENSOR_OK", ",\"sensor\":\"water\"");
  }

  if (raw < DRY_LEVEL) {
    if (!isDry) { isDry = true; dryStart = millis(); }
  } else {
    isDry = false;
  }

  buf[head] = raw;
  head = (head + 1) % WIN;
  if (count < WIN) count++;
}

float slopeOf(int start, int n) { // least-squares growth speed, units per second
  float sx = 0, sy = 0, sxx = 0, sxy = 0;
  for (int i = 0; i < n; i++) {
    float x = i * (SAMPLE_MS / 1000.0f);
    float y = sampleAt(start + i);
    sx += x; sy += y; sxx += x * x; sxy += x * y;
  }
  float d = n * sxx - sx * sx;
  return d == 0 ? 0 : (n * sxy - sx * sy) / d;
}

void computeFeatures() {
  float sum = 0, mn = 1e9, mx = -1e9;
  for (int i = 0; i < WIN; i++) {
    int v = sampleAt(i);
    if (v < mn) mn = v;
    if (v > mx) mx = v;
    if (i >= WIN - 5) sum += v;
  }
  feat.level   = sum / 5.0f;
  feat.slopeA  = slopeOf(0, HALF);
  feat.slopeB  = slopeOf(WIN - HALF, HALF);
  feat.minV    = mn;
  feat.maxV    = mx;
  feat.hum     = hum;
  feat.humRate = humRate;
}

// ------------------------------------------------------------------ decision
// >>> AI HOOK <<<
// Matches the Decision Tree structure over the 25-sample (5s) window features.
Cls classifyWindow(const Features& f) {
  if (f.level >= FLOOD_LEVEL) return C_LEAK;                       // a lot of water: always a leak
  if (f.level >= WET_LEVEL) {
    if (f.slopeA > GROW_RATE && f.slopeB > GROW_RATE) return C_LEAK; // keeps growing: leak
    return C_SPILL;                                                // wet but not growing: spill
  }
  if (!isnan(f.hum) && (f.hum >= HUMID_LEVEL || f.humRate >= HUMID_RATE)) return C_HUMID;
  return C_NORMAL;
}

void printStatus() {
  char humStr[16], tempStr[16], payload[420];
  if (isnan(hum))  strcpy(humStr, "null");  else snprintf(humStr, sizeof(humStr), "%.1f", hum);
  if (isnan(temp)) strcpy(tempStr, "null"); else snprintf(tempStr, sizeof(tempStr), "%.1f", temp);

  const char* clsStr = waterFault ? "SENSOR_FAULT" : (count < WIN ? "WARMUP" : CLS_NAME[lastCls]);
  float leakRate = feat.slopeB > 0 ? feat.slopeB : 0.0f;

  snprintf(payload, sizeof(payload),
    "{\"ms\":%lu,\"level\":%.0f,\"slopeA\":%.1f,\"slopeB\":%.1f,\"leakRate\":%.1f,"
    "\"minV\":%.0f,\"maxV\":%.0f,\"hum\":%s,\"temp\":%s,\"humRate\":%.2f,"
    "\"class\":\"%s\",\"state\":\"%s\",\"valve\":\"%s\",\"alarm\":%s,\"silenced\":%s,"
    "\"waterFault\":%s,\"humFault\":%s,\"sysArmed\":%s}",
    millis(), feat.level, feat.slopeA, feat.slopeB, leakRate,
    feat.minV, feat.maxV, humStr, tempStr, feat.humRate,
    clsStr, STATE_NAME[state], valveOpen ? "OPEN" : "CLOSED",
    alarmActive() ? "true" : "false", alarmSilenced ? "true" : "false",
    waterFault ? "true" : "false", humFault ? "true" : "false",
    systemArmed ? "true" : "false"
  );

  Serial.printf("STATUS %s\n", payload);
  if (mqtt.connected()) {
    mqtt.publish(TOPIC_STATUS, payload);
  }
}

void printCsv() {
  char humStr[16], csvLine[200];
  if (isnan(feat.hum)) strcpy(humStr, "null"); else snprintf(humStr, sizeof(humStr), "%.1f", feat.hum);

  snprintf(csvLine, sizeof(csvLine), "CSV,%lu,%.1f,%.2f,%.2f,%.0f,%.0f,%s,%.2f,%d",
           millis(), feat.level, feat.slopeA, feat.slopeB, feat.minV, feat.maxV,
           humStr, feat.humRate, label);
  Serial.println(csvLine);
  if (mqtt.connected()) {
    mqtt.publish(TOPIC_CSV, csvLine);
  }
}

void decide() {
  if (count < WIN || waterFault) { printStatus(); return; }

  computeFeatures();
  Cls c = classifyWindow(feat);

  if (systemArmed) {
    if (c == C_LEAK) {
      if (leakCount == 0) firstLeakMs = millis();
      leakCount++;
    } else {
      leakCount = 0;
    }

    if (c != lastCls) {
      char x[48];
      snprintf(x, sizeof x, ",\"class\":\"%s\"", CLS_NAME[c]);
      event("CLASS_CHANGED", x);
      if (c == C_SPILL && state == WATER_ON) flash(2, 60); // small warning, water stays on
      lastCls = c;
    }

    if (state == WATER_ON && leakCount >= CONFIRM_COUNT) closeWater(LEAK_OFF, "leak confirmed");
  }

  printStatus();
  if (csvOn) printCsv();
}

// ------------------------------------------------------------------ DHT22
void readDht() {
  float h = dht.readHumidity();
  float t = dht.readTemperature();
  unsigned long now = millis();
  if (isnan(h) || isnan(t)) {
    if (!humFault) { humFault = true; event("SENSOR_FAULT", ",\"sensor\":\"humidity\""); }
    hum = NAN; temp = NAN; humRate = 0; // leak detection keeps working with the water sensor
    return;
  }
  if (humFault) { humFault = false; event("SENSOR_OK", ",\"sensor\":\"humidity\""); }
  if (!isnan(prevHum) && now > prevHumMs) humRate = (h - prevHum) / ((now - prevHumMs) / 1000.0f);
  prevHum = h; prevHumMs = now;
  hum = h; temp = t;
}

// ------------------------------------------------------------------ badge
void onBadge(const String& uid, bool allowed) {
  char x[80];
  snprintf(x, sizeof x, ",\"uid\":\"%s\"", uid.c_str());
  if (!allowed) {
    event("BADGE_REFUSED", x);
    flash(3, 80);
    return;
  }
  event("BADGE_OK", x);
  if (state == WATER_ON) flash(1, 60);
  else tryOpen("badge");
}

#if SIMULATION
bool pressedEdge(int pin, bool& prev) {
  bool now = digitalRead(pin) == LOW;
  bool edge = now && !prev;
  prev = now;
  return edge;
}

void pollBadge() {
  static bool prevOk = false, prevBad = false;
  if (pressedEdge(PIN_BADGE_OK, prevOk))   onBadge("SIM-ALLOWED", true);
  if (pressedEdge(PIN_BADGE_BAD, prevBad)) onBadge("SIM-UNKNOWN", false);
}
#else
void pollBadge() {
  if (!rfid.PICC_IsNewCardPresent() || !rfid.PICC_ReadCardSerial()) return;
  String uid;
  for (byte i = 0; i < rfid.uid.size; i++) {
    if (i) uid += ":";
    if (rfid.uid.uidByte[i] < 0x10) uid += "0";
    uid += String(rfid.uid.uidByte[i], HEX);
  }
  uid.toUpperCase();
  rfid.PICC_HaltA();
  bool allowed = false;
  for (int i = 0; i < ALLOWED_COUNT; i++) if (uid == ALLOWED_UIDS[i]) allowed = true;
  onBadge(uid, allowed);
}
#endif

// ------------------------------------------------------------------ commands (Serial & MQTT)
void runCommand(String cmd, const char* by = "dashboard") {
  cmd.trim();
  cmd.toUpperCase();
  if (cmd == "CLOSE") {
    if (valveOpen) closeWater(MANUAL_OFF, "manual close");
    else event("CLOSE_IGNORED", ",\"reason\":\"already closed\"");
  } else if (cmd == "OPEN") {
    tryOpen(by);
  } else if (cmd == "SILENCE") {
    alarmSilenced = true;
    event("ALARM_SILENCED", "");
  } else if (cmd == "SYS_OFF") {
    systemArmed = false;
    alarmSilenced = true;
    event("SYSTEM_DISARMED", ",\"by\":\"admin\"");
  } else if (cmd == "SYS_ON") {
    systemArmed = true;
    event("SYSTEM_ARMED", ",\"by\":\"admin\"");
  } else if (cmd == "STATUS") {
    printStatus();
  } else if (cmd == "CSV ON") {
    csvOn = true;
    Serial.println("CSV,ms,level,slopeA,slopeB,min,max,hum,humRate,label");
    event("CSV_MODE", ",\"enabled\":true");
  } else if (cmd == "CSV OFF") {
    csvOn = false;
    event("CSV_MODE", ",\"enabled\":false");
  } else if (cmd.startsWith("LABEL ")) {
    label = cmd.substring(6).toInt();
    char x[24];
    snprintf(x, sizeof x, ",\"label\":%d", label);
    event("LABEL_SET", x);
  } else {
    event("UNKNOWN_COMMAND", "");
  }
}

void handleSerial() {
  static String line;
  while (Serial.available()) {
    char ch = Serial.read();
    if (ch == '\n' || ch == '\r') {
      if (line.length()) runCommand(line, "serial");
      line = "";
    } else if (line.length() < 40) {
      line += ch;
    }
  }
}

// ------------------------------------------------------------------ Layer 3: HMAC-SHA256 & MQTT
String computeHMAC(const String& msg) {
  byte hmacResult[32];
  mbedtls_md_context_t ctx;
  mbedtls_md_init(&ctx);
  mbedtls_md_setup(&ctx, mbedtls_md_info_from_type(MBEDTLS_MD_SHA256), 1);
  mbedtls_md_hmac_starts(&ctx, (const unsigned char*)SHARED_SECRET, strlen(SHARED_SECRET));
  mbedtls_md_hmac_update(&ctx, (const unsigned char*)msg.c_str(), msg.length());
  mbedtls_md_hmac_finish(&ctx, hmacResult);
  mbedtls_md_free(&ctx);

  char hexStr[65];
  for (int i = 0; i < 32; i++) sprintf(hexStr + (i * 2), "%02x", hmacResult[i]);
  hexStr[64] = 0;
  return String(hexStr);
}

String extractJsonStr(const String& json, const char* key) {
  String search = String("\"") + key + "\":\"";
  int start = json.indexOf(search);
  if (start == -1) return "";
  start += search.length();
  int end = json.indexOf("\"", start);
  return (end == -1) ? "" : json.substring(start, end);
}

long extractJsonLong(const String& json, const char* key) {
  String search = String("\"") + key + "\":";
  int start = json.indexOf(search);
  if (start == -1) return 0;
  start += search.length();
  return json.substring(start).toInt();
}

void onMqttMessage(char* topic, byte* payload, unsigned int length) {
  String msg;
  for (unsigned int i = 0; i < length; i++) msg += (char)payload[i];

  String cmd  = extractJsonStr(msg, "cmd");
  String user = extractJsonStr(msg, "user");
  String sig  = extractJsonStr(msg, "sig");
  long   seq  = extractJsonLong(msg, "seq");

  // Verify HMAC-SHA256 signature and anti-replay sequence number
  String expectedSig = computeHMAC(cmd + ":" + String(seq));
  if (!sig.equalsIgnoreCase(expectedSig) || seq <= lastSeq) {
    char x[120];
    snprintf(x, sizeof x, ",\"cmd\":\"%s\",\"by\":\"%s\",\"reason\":\"invalid HMAC or replay\"", cmd.c_str(), user.c_str());
    event("SECURITY_BLOCKED", x);
    flash(3, 80);
    return;
  }
  lastSeq = seq;
  runCommand(cmd, user.length() ? user.c_str() : "dashboard");
}

void maintainMqtt() {
  if (WiFi.status() != WL_CONNECTED) return;
  if (mqtt.connected()) {
    mqtt.loop();
    return;
  }
  unsigned long now = millis();
  if (now - tMqttRetry >= 3000) {
    tMqttRetry = now;
    String clientId = "fusrodah_esp32_" + String(random(1000, 9999));
    if (mqtt.connect(clientId.c_str(), MQTT_USER, MQTT_PASS)) {
      mqtt.subscribe(TOPIC_COMMANDS);
      event("MQTT_TLS_CONNECTED", ",\"port\":8883");
      printStatus();
    }
  }
}

// ------------------------------------------------------------------ setup and loop
void setup() {
  Serial.begin(115200);
  pinMode(PIN_WATER_PWR, OUTPUT);
  digitalWrite(PIN_WATER_PWR, LOW);
  pinMode(PIN_LED_RED, OUTPUT);
  pinMode(PIN_LED_GREEN, OUTPUT);
  pinMode(PIN_LED_YELLOW, OUTPUT);
  // Weakest output (~5 mA) to protect resistor-less LEDs and ESP32
  gpio_set_drive_capability((gpio_num_t)PIN_LED_RED,    GPIO_DRIVE_CAP_0);
  gpio_set_drive_capability((gpio_num_t)PIN_LED_YELLOW, GPIO_DRIVE_CAP_0);
  gpio_set_drive_capability((gpio_num_t)PIN_LED_GREEN,  GPIO_DRIVE_CAP_0);
  pinMode(PIN_WATER_SIG, INPUT_PULLUP);
  analogReadResolution(12);

  dht.begin();
  valve.setPeriodHertz(50);
  valve.attach(PIN_SERVO, 500, 2400);
  valve.write(SERVO_OPEN);

#if SIMULATION
  pinMode(PIN_BADGE_OK, INPUT_PULLUP);
  pinMode(PIN_BADGE_BAD, INPUT_PULLUP);
#else
  SPI.begin();
  rfid.PCD_Init();
#endif

  // Connect Wi-Fi & configure TLS (non-blocking if Wi-Fi is down)
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  espClient.setInsecure(); // Encrypts traffic via TLS 8883 without requiring root CA flash
  mqtt.setServer(MQTT_BROKER, MQTT_PORT_TLS);
  mqtt.setBufferSize(512);
  mqtt.setCallback(onMqttMessage);

  dryStart = millis();
  event("BOOT", SIMULATION ? ",\"mode\":\"simulation\"" : ",\"mode\":\"hardware\"");
}

void loop() {
  unsigned long now = millis();
  if (now - tSample >= SAMPLE_MS) { tSample = now; sampleWater(); }
  if (now - tDht    >= 2000)      { tDht    = now; readDht(); }
  if (now - tDecide >= 1000)      { tDecide = now; decide(); }
  if (now - tBadge  >= 50)        { tBadge  = now; pollBadge(); }
  handleSerial();
  maintainMqtt();
  updateLeds();
}